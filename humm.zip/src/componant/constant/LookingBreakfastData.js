export const LookingBreakfastData = [
  {
    id:1,
    title:"Cappuccino",
    description:"North End Coffe Roast...",
    currency:"₹",
    price:"250",
    offer:"",
    isFreeDelevery:"Free Delivery",
    images:"https://cdn.myonlinestore.eu/9479208f-6be1-11e9-a722-44a8421b9960/image/cache/full/63bfdfeecf25cbd391f4a201f7ef840b61880a64.jpg"
  },
  {
    id:2,
    title:"Cappuccino",
    description:"North End Coffe Roast...",
    currency:"₹",
    price:"250",
    offer:"25% off",
    isFreeDelevery:"",
    images:"https://culturedcoffeeco.com/wp-content/uploads/2021/09/Cappuccino.jpeg"
  },
  {
    id:3,
    title:"Cappuccino",
    description:"North End Coffe Roast...",
    currency:"₹",
    price:"250",
    offer:"25% off",
    isFreeDelevery:"Free Delivery",
    images:"https://wallpapercave.com/wp/wp2378648.jpg"
  },
  {
    id:4,
    title:"Cappuccino",
    description:"North End Coffe Roast...",
    currency:"₹",
    price:"250",
    offer:"25% off",
    isFreeDelevery:"Free Delivery",
    images:"https://image.arrivalguides.com/1230x800/01/acf00fc483c48cc9c51415937ca1af53.jpg"
  },
  {
    id:5,
    title:"Cappuccino",
    description:"North End Coffe Roast...",
    currency:"₹",
    price:"250",
    offer:"25% off",
    isFreeDelevery:"Free Delivery",
    images:"https://cdn.myonlinestore.eu/9479208f-6be1-11e9-a722-44a8421b9960/image/cache/full/63bfdfeecf25cbd391f4a201f7ef840b61880a64.jpg"
  },
  {
    id:6,
    title:"Cappuccino",
    description:"North End Coffe Roast...",
    currency:"₹",
    price:"250",
    offer:"25% off",
    isFreeDelevery:"Free Delivery",
    images:"https://wallbox.ru/wallpapers/main2/201718/risunok-korica-kofe-caska-pena-kapucino.jpg"
  },
  {
    id:7,
    title:"Cappuccino",
    description:"North End Coffe Roast...",
    currency:"₹",
    price:"250",
    offer:"25% off",
    isFreeDelevery:"Free Delivery",
    images:"https://avatars.mds.yandex.net/get-zen_doc/1686231/pub_5e554007bb4a6d368b8e272f_5e5541d3bb4a6d368b8e275c/scale_1200"
  }
]