export const RestaurantsNearYouData = [
  {
    id:1,
    title:"The Steak House",
    distance:"15min",
    rating:"4.2",
    foodType:[
      "Steak","Fish","Burgers"
    ],
    images:"https://gatewayinteriors.ae/wp-content/uploads/2021/12/file1454623672.jpg"
  },
  {
    id:2,
    title:"Foodies",
    distance:"30min",
    rating:"4.2",
    foodType:[
      "Steak","Fish","Burgers"
    ],
    images:"https://i.pinimg.com/originals/d7/f5/66/d7f5667c31446af13d0dd73a6306c014.jpg"
  },
  {
    id:3,
    title:"The Steak House",
    distance:"10min",
    rating:"4.2",
    foodType:[
      "Steak","Fish","Burgers"
    ],
    images:"https://i.pinimg.com/originals/d7/ca/0f/d7ca0f7a89e38bfab37668f78f974450.jpg"
  },
  {
    id:4,
    title:"Foodies",
    distance:"25min",
    rating:"4.2",
    foodType:[
      "Steak","Fish","Burgers"
    ],
    images:"https://i.pinimg.com/originals/3f/d0/f7/3fd0f7a036f2b8c8e0bc310787979f2d.jpg"
  },
  {
    id:5,
    title:"The Steak House",
    distance:"45min",
    rating:"4.2",
    foodType:[
      "Steak","Fish","Burgers"
    ],
    images:"https://i.pinimg.com/originals/b4/08/a3/b408a3711d67f71e5d0aceb63f44e9f4.jpg"
  },
  {
    id:6,
    title:"Foodies",
    description:"North End Coffe Roast...",
    ddistance:"20min",
    rating:"4.2",
    foodType:[
      "Steak","Fish","Burgers"
    ],
    images:"https://i.pinimg.com/originals/b4/08/a3/b408a3711d67f71e5d0aceb63f44e9f4.jpg"
  },
  {
    id:7,
    title:"The Steak House",
    description:"North End Coffe Roast...",
    distance:"18min",
    rating:"4.2",
    foodType:[
      "Steak","Fish","Burgers"
    ],
    images:"http://cdn.shopify.com/s/files/1/0325/5877/6379/collections/909E7FA3-C862-42B1-8545-91D2C71F1071_1200x1200.jpg?v=1582975747"
  }
]